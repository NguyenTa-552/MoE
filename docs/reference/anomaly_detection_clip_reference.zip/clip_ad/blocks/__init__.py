"""Optional representation blocks."""
